import os
import requests
import xml.etree.ElementTree as ET
import logging
from flask import Flask, render_template, request, jsonify
import urllib.parse
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Default API key for National Assembly OpenAPI
DEFAULT_API_KEY = os.environ.get("ASSEMBLY_API_KEY", "aaaadb7517494adf9aa2b11398b3fd76")

# National Assembly API endpoints
BILL_API_URL = "https://open.assembly.go.kr/portal/openapi/nzmimeepazxkubdpn"
MEMBER_API_URL = "https://open.assembly.go.kr/portal/openapi/nwvrqwxyaytdsfvhu"

# RSS feed URLs
MOF_RSS_URL = "https://www.moef.go.kr/com/detailRssTagService.do?bbsId=MOSFBBS_000000000028"
FSC_RSS_URL = "http://www.fsc.go.kr/about/fsc_bbs_rss/?fid=0111"

@app.route('/')
def index():
    """Redirect to the bills search page by default"""
    return render_template('bills.html', 
                           active_tab='bills',
                           assembly_terms=range(17, 23))

@app.route('/bill', methods=['GET'])
def bill_search():
    """Handle bill search queries"""
    assembly_term = request.args.get('assembly_term', '21')
    keyword = request.args.get('keyword', '')
    page = int(request.args.get('page', '1'))
    items_per_page = int(request.args.get('items_per_page', '5'))
    api_key = request.args.get('api_key', DEFAULT_API_KEY)
    
    if not keyword:
        return render_template('bills.html', 
                               active_tab='bills',
                               assembly_terms=range(17, 23),
                               assembly_term=assembly_term,
                               bills=[],
                               total_count=0,
                               current_page=page,
                               total_pages=0,
                               keyword=keyword)
    
    # Calculate start index for pagination
    start_index = (page - 1) * items_per_page + 1
    
    # Prepare API request
    params = {
        'KEY': api_key,
        'Type': 'xml',
        'AGE': assembly_term,
        'BILL_NAME': keyword,
        'pIndex': page,
        'pSize': items_per_page
    }
    
    try:
        response = requests.get(BILL_API_URL, params=params)
        
        # Parse XML response
        root = ET.fromstring(response.content)
        
        # Extract data from API response
        bills = []
        total_count = 0
        
        # Get total count from the response
        count_elem = root.find('.//head/list_total_count')
        if count_elem is not None:
            total_count = int(count_elem.text)
        
        # Get all row elements
        rows = root.findall('.//row')
        
        if rows:
            for row in rows:
                bill_id = row.find('BILL_ID').text if row.find('BILL_ID') is not None else ''
                bills.append({
                    'bill_id': bill_id,
                    'bill_no': row.find('BILL_NO').text if row.find('BILL_NO') is not None else '',
                    'bill_name': row.find('BILL_NAME').text if row.find('BILL_NAME') is not None else '',
                    'proposer': row.find('PROPOSER').text if row.find('PROPOSER') is not None else '',
                    'propose_date': row.find('PROPOSE_DT').text if row.find('PROPOSE_DT') is not None else '',
                    'committee': row.find('CURR_COMMITTEE').text if row.find('CURR_COMMITTEE') is not None else '',
                    'status': None if row.find('PROC_RESULT') is None or row.find('PROC_RESULT').text == 'None' or row.find('PROC_RESULT').text == None else row.find('PROC_RESULT').text,
                    'url': f"https://likms.assembly.go.kr/bill/billDetail.do?billId={bill_id}"
                })
        
        total_pages = (total_count + items_per_page - 1) // items_per_page
        
        return render_template('bills.html', 
                               active_tab='bills',
                               assembly_terms=range(17, 23),
                               assembly_term=assembly_term,
                               bills=bills,
                               total_count=total_count,
                               current_page=page,
                               total_pages=total_pages,
                               keyword=keyword)
    
    except Exception as e:
        logging.error(f"Error fetching bill data: {e}")
        return render_template('bills.html', 
                               active_tab='bills',
                               assembly_terms=range(17, 23),
                               assembly_term=assembly_term,
                               bills=[],
                               error=str(e),
                               keyword=keyword)

@app.route('/member', methods=['GET'])
def member_search():
    """Handle member search queries"""
    assembly_term = request.args.get('assembly_term', '21')
    keyword = request.args.get('keyword', '')
    api_key = request.args.get('api_key', DEFAULT_API_KEY)
    
    if not keyword:
        return render_template('members.html', 
                               active_tab='members',
                               assembly_terms=range(17, 23),
                               assembly_term=assembly_term,
                               members=[],
                               keyword=keyword)
    
    # Prepare API request
    params = {
        'KEY': api_key,
        'Type': 'xml',
        'AGE': assembly_term,
        'HG_NM': keyword,
        'pIndex': 1,
        'pSize': 50  # Get more results for members as the total count is typically small
    }
    
    try:
        response = requests.get(MEMBER_API_URL, params=params)
        
        # Parse XML response
        root = ET.fromstring(response.content)
        
        # Extract data from API response
        members = []
        
        # Get all row elements
        rows = root.findall('.//row')
        
        if rows:
            for row in rows:
                assem_addr = row.find('ASSEM_ADDR').text if row.find('ASSEM_ADDR') is not None else ''
                members.append({
                    'name': row.find('HG_NM').text if row.find('HG_NM') is not None else '',
                    'party': row.find('POLY_NM').text if row.find('POLY_NM') is not None else '',
                    'district': row.find('ORIG_NM').text if row.find('ORIG_NM') is not None else '',
                    'committee': row.find('CMIT_NM').text if row.find('CMIT_NM') is not None else '',
                    'elected_times': row.find('REELE_GBN_NM').text if row.find('REELE_GBN_NM') is not None else '',
                    'birthday': row.find('BTH_DATE').text if row.find('BTH_DATE') is not None else '',
                    'photo_url': row.find('HJ_URL').text if row.find('HJ_URL') is not None else '',
                    'profile_url': f"https://www.assembly.go.kr/assm/memPop/memPopup.do?dept_cd={assem_addr}"
                })
        
        return render_template('members.html', 
                               active_tab='members',
                               assembly_terms=range(17, 23),
                               assembly_term=assembly_term,
                               members=members,
                               keyword=keyword)
    
    except Exception as e:
        logging.error(f"Error fetching member data: {e}")
        return render_template('members.html', 
                               active_tab='members',
                               assembly_terms=range(17, 23),
                               assembly_term=assembly_term,
                               members=[],
                               error=str(e),
                               keyword=keyword)

@app.route('/press/mof', methods=['GET'])
def press_mof():
    """Handle Ministry of Economy and Finance press release queries"""
    page = int(request.args.get('page', '1'))
    items_per_page = int(request.args.get('items_per_page', '5'))
    
    try:
        response = requests.get(MOF_RSS_URL)
        
        # Parse XML
        root = ET.fromstring(response.content)
        
        # Extract items from RSS feed
        items = []
        for item in root.findall('.//item'):
            title = item.find('title').text if item.find('title') is not None else ''
            link = item.find('link').text if item.find('link') is not None else ''
            pub_date_text = item.find('pubDate').text if item.find('pubDate') is not None else ''
            description = item.find('description').text if item.find('description') is not None else ''
            
            # Parse and format the publication date
            try:
                pub_date = datetime.strptime(pub_date_text, '%a, %d %b %Y %H:%M:%S %z')
                formatted_date = pub_date.strftime('%Y-%m-%d')
            except:
                formatted_date = pub_date_text
            
            items.append({
                'title': title,
                'link': link,
                'pub_date': formatted_date,
                'description': description
            })
        
        # Implement pagination
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paginated_items = items[start_idx:end_idx]
        total_count = len(items)
        total_pages = (total_count + items_per_page - 1) // items_per_page
        
        return render_template('press_mof.html', 
                               active_tab='mof',
                               items=paginated_items,
                               total_count=total_count,
                               current_page=page,
                               total_pages=total_pages)
    
    except Exception as e:
        logging.error(f"Error fetching MOF press releases: {e}")
        return render_template('press_mof.html', 
                               active_tab='mof',
                               items=[],
                               error=str(e))

@app.route('/press/fsc', methods=['GET'])
def press_fsc():
    """Handle Financial Services Commission press release queries"""
    page = int(request.args.get('page', '1'))
    items_per_page = int(request.args.get('items_per_page', '5'))
    
    try:
        response = requests.get(FSC_RSS_URL)
        
        # Parse XML
        root = ET.fromstring(response.content)
        
        # Register DC namespace for handling dc:date
        namespaces = {'dc': 'http://purl.org/dc/elements/1.1/'}
        
        # Extract items from RSS feed
        items = []
        for item in root.findall('.//item'):
            title = item.find('title').text if item.find('title') is not None else ''
            link = item.find('link').text if item.find('link') is not None else ''
            
            # Try to get dc:date first, then fallback to pubDate
            dc_date_elem = item.find('.//dc:date', namespaces)
            pub_date_text = ''
            if dc_date_elem is not None and dc_date_elem.text:
                pub_date_text = dc_date_elem.text
            else:
                pub_date_elem = item.find('pubDate')
                if pub_date_elem is not None:
                    pub_date_text = pub_date_elem.text
            
            description = item.find('description').text if item.find('description') is not None else ''
            
            # Parse and format the publication date
            formatted_date = ''
            if pub_date_text:
                try:
                    # Try ISO format (for dc:date)
                    try:
                        pub_date = datetime.fromisoformat(pub_date_text.replace('Z', '+00:00'))
                        formatted_date = pub_date.strftime('%Y-%m-%d')
                    except ValueError:
                        # Try RSS format (for pubDate)
                        pub_date = datetime.strptime(pub_date_text, '%a, %d %b %Y %H:%M:%S %z')
                        formatted_date = pub_date.strftime('%Y-%m-%d')
                except:
                    formatted_date = pub_date_text
            
            items.append({
                'title': title,
                'link': link,
                'pub_date': formatted_date,
                'description': description
            })
        
        # Implement pagination
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paginated_items = items[start_idx:end_idx]
        total_count = len(items)
        total_pages = (total_count + items_per_page - 1) // items_per_page
        
        return render_template('press_fsc.html', 
                               active_tab='fsc',
                               items=paginated_items,
                               total_count=total_count,
                               current_page=page,
                               total_pages=total_pages)
    
    except Exception as e:
        logging.error(f"Error fetching FSC press releases: {e}")
        return render_template('press_fsc.html', 
                               active_tab='fsc',
                               items=[],
                               error=str(e))

@app.route('/settings', methods=['GET'])
def settings():
    """Handle settings page"""
    return render_template('settings.html', 
                           active_tab='settings',
                           assembly_terms=range(17, 23),
                           default_api_key=DEFAULT_API_KEY)

@app.template_filter('truncate_text')
def truncate_text(text, length=100):
    """Template filter to truncate text to a specified length"""
    if not text:
        return ""
    if len(text) <= length:
        return text
    return text[:length] + '...'

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
