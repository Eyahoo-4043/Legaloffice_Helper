/**
 * Main JavaScript file for National Assembly search application
 */

// Initialize the application when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Load settings from localStorage
    loadSettings();
    
    // Set up event listeners
    setupEventListeners();
});

/**
 * Load user settings from localStorage
 */
function loadSettings() {
    // Get settings form elements if they exist
    const apiKeyInput = document.getElementById('api-key');
    const defaultTermSelect = document.getElementById('default-term');
    const itemsPerPageSelect = document.getElementById('items-per-page');
    
    // Get current form values for search forms
    const searchTermSelects = document.querySelectorAll('.assembly-term-select');
    
    // Load API key
    const savedApiKey = localStorage.getItem('apiKey');
    if (savedApiKey && apiKeyInput) {
        apiKeyInput.value = savedApiKey;
    }
    
    // Load default assembly term
    const savedDefaultTerm = localStorage.getItem('defaultTerm');
    if (savedDefaultTerm) {
        if (defaultTermSelect) {
            defaultTermSelect.value = savedDefaultTerm;
        }
        
        // Apply to all term selects on search forms
        searchTermSelects.forEach(select => {
            select.value = savedDefaultTerm;
        });
    }
    
    // Load items per page
    const savedItemsPerPage = localStorage.getItem('itemsPerPage');
    if (savedItemsPerPage && itemsPerPageSelect) {
        itemsPerPageSelect.value = savedItemsPerPage;
    }
}

/**
 * Set up event listeners for the application
 */
function setupEventListeners() {
    // Handle form submission for settings
    const settingsForm = document.getElementById('settings-form');
    if (settingsForm) {
        settingsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveSettings();
        });
    }
    
    // Handle API key change button click
    const changeApiKeyBtn = document.getElementById('change-api-key');
    if (changeApiKeyBtn) {
        changeApiKeyBtn.addEventListener('click', function() {
            const apiKeyInput = document.getElementById('api-key');
            if (apiKeyInput) {
                localStorage.setItem('apiKey', apiKeyInput.value);
                
                // Show success message
                const successMessage = document.getElementById('settings-success');
                if (successMessage) {
                    successMessage.textContent = 'API 키가 변경되었습니다.';
                    successMessage.style.display = 'block';
                    setTimeout(() => {
                        successMessage.style.display = 'none';
                    }, 3000);
                }
            }
        });
    }
    
    // Handle info icon click for source information
    const infoIcon = document.querySelector('.info-icon');
    if (infoIcon) {
        infoIcon.addEventListener('click', function() {
            const apiSources = document.querySelector('.api-sources');
            if (apiSources) {
                if (apiSources.style.display === 'none') {
                    apiSources.style.display = 'block';
                } else {
                    apiSources.style.display = 'none';
                }
            }
        });
    }
    
    // Handle tab clicks
    const tabItems = document.querySelectorAll('.tab-item');
    tabItems.forEach(tab => {
        tab.addEventListener('click', function() {
            navigateToTab(this.dataset.tab);
        });
    });
    
    // Handle pagination clicks
    const paginationLinks = document.querySelectorAll('.pagination-item');
    paginationLinks.forEach(link => {
        if (!link.classList.contains('disabled') && !link.classList.contains('active')) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                navigateToPage(this.dataset.page);
            });
        }
    });
}

/**
 * Save user settings to localStorage
 */
function saveSettings() {
    const apiKey = document.getElementById('api-key').value;
    const defaultTerm = document.getElementById('default-term').value;
    const itemsPerPage = document.getElementById('items-per-page').value;
    
    // Save to localStorage
    localStorage.setItem('apiKey', apiKey);
    localStorage.setItem('defaultTerm', defaultTerm);
    localStorage.setItem('itemsPerPage', itemsPerPage);
    
    // Show success message
    const successMessage = document.getElementById('settings-success');
    if (successMessage) {
        successMessage.style.display = 'block';
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 3000);
    }
}

/**
 * Navigate to specified tab
 * @param {string} tabName - The name of the tab to navigate to
 */
function navigateToTab(tabName) {
    let url = '/';
    
    switch(tabName) {
        case 'bills':
            url = '/bill';
            break;
        case 'members':
            url = '/member';
            break;
        case 'mof':
            url = '/press/mof';
            break;
        case 'fsc':
            url = '/press/fsc';
            break;
        case 'settings':
            url = '/settings';
            break;
    }
    
    window.location.href = url;
}

/**
 * Navigate to a specific page for pagination
 * @param {string} page - The page number to navigate to
 */
function navigateToPage(page) {
    const currentUrl = new URL(window.location.href);
    currentUrl.searchParams.set('page', page);
    
    // Apply saved items per page if available
    const savedItemsPerPage = localStorage.getItem('itemsPerPage');
    if (savedItemsPerPage) {
        currentUrl.searchParams.set('items_per_page', savedItemsPerPage);
    }
    
    // Apply saved API key if available and needed
    if (currentUrl.pathname === '/bill' || currentUrl.pathname === '/member') {
        const savedApiKey = localStorage.getItem('apiKey');
        if (savedApiKey) {
            currentUrl.searchParams.set('api_key', savedApiKey);
        }
    }
    
    window.location.href = currentUrl.toString();
}

/**
 * Apply search with current settings
 * @param {string} formId - The ID of the form to submit
 */
function applySearch(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    // Apply saved API key if available
    const savedApiKey = localStorage.getItem('apiKey');
    if (savedApiKey) {
        const apiKeyInput = document.createElement('input');
        apiKeyInput.type = 'hidden';
        apiKeyInput.name = 'api_key';
        apiKeyInput.value = savedApiKey;
        form.appendChild(apiKeyInput);
    }
    
    // Apply saved items per page if available
    const savedItemsPerPage = localStorage.getItem('itemsPerPage');
    if (savedItemsPerPage) {
        const itemsPerPageInput = document.createElement('input');
        itemsPerPageInput.type = 'hidden';
        itemsPerPageInput.name = 'items_per_page';
        itemsPerPageInput.value = savedItemsPerPage;
        form.appendChild(itemsPerPageInput);
    }
    
    form.submit();
}
